<?php
defined('MOODLE_INTERNAL') || die();

class block_simplecalculator extends block_base {
    public function init() {
        $this->title = get_string('pluginname', 'block_simplecalculator');
    }

    public function get_content() {
        global $PAGE;
        if ($this->content !== null) {
            return $this->content;
        }
        $this->content = new stdClass();
        $this->content->text = $this->content_html();
        $this->content->footer = '';
        return $this->content;
    }

    private function content_html() {
        global $OUTPUT, $PAGE;
        $PAGE->requires->css('/blocks/simplecalculator/styles.css');
        return $OUTPUT->render_from_template('block_simplecalculator/calculator', []);
    }

    public function applicable_formats() {
        return ['all' => true];
    }
}
