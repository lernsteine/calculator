<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Simple Calculator';
$string['simplecalculator:addinstance'] = 'Add a calculator block';
$string['simplecalculator:myaddinstance'] = 'Add calculator to dashboard';
